package com.itc.ratefiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatefilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
