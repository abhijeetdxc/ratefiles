package com.itc.ratefiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatefilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RatefilesApplication.class, args);
	}

}
