package com.itc.ratefiles.repository;

import com.itc.ratefiles.entities.Ratesjordan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RatesRepository extends JpaRepository<Ratesjordan,Long> {

}
